package com.ali.wb.survey.aviator_script_survey.demo.entity;

import com.googlecode.aviator.Expression;

public class CompiledRuleExpression {

    private String originalExpressionStr;

    private Expression compiledExpression;

    public CompiledRuleExpression(String originalExpressionStr, Expression compiledExpression) {
        this.originalExpressionStr = originalExpressionStr;
        this.compiledExpression = compiledExpression;
    }

    public String getOriginalExpressionStr() {
        return originalExpressionStr;
    }

    public void setOriginalExpressionStr(String originalExpressionStr) {
        this.originalExpressionStr = originalExpressionStr;
    }

    public Expression getCompiledExpression() {
        return compiledExpression;
    }

    public void setCompiledExpression(Expression compiledExpression) {
        this.compiledExpression = compiledExpression;
    }
}
