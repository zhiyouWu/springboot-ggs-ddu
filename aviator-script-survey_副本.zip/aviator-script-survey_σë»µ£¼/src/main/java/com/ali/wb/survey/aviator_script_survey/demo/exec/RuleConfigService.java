package com.ali.wb.survey.aviator_script_survey.demo.exec;

import com.ali.wb.survey.aviator_script_survey.demo.entity.CompiledRuleExpression;
import com.ali.wb.survey.aviator_script_survey.demo.entity.Rule;
import com.ali.wb.survey.aviator_script_survey.demo.entity.SubRule;
import com.ali.wb.survey.aviator_script_survey.demo.entity.Variable;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RuleConfigService {
    private final Map<Integer, Map<Integer, String>> subRuleExpressionMap = new HashMap<>();
    // private final Map<Integer, String> ruleExpressions = new HashMap<>();
    // 使用编译后的表达式
    private final Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = new HashMap<>();

    Map<String, String> opMap = Map.of(
            "EQUAL", "==",
            "LESS", "<",
            "GREATER", ">",
            "LESS_EQUAL", "<=",
            "GREATER_EQUAL", ">=",
            "NOT_EQUAL", "!=",
            "IN", "in"
    );

    @PostConstruct
    public void loadRules() {
        // 模拟从数据库加载规则配置
        List<SubRule> subRules = List.of(
                // ruleId = 91
                new SubRule(1, 1, new Variable(true, "yw_score", "INTEGER"), new Variable(false, "90", "INTEGER"), "GREATER_EQUAL", 91),
                new SubRule(2, 2, new Variable(true, "yw_score", "INTEGER"), new Variable(false, "130", "INTEGER"), "LESS_EQUAL", 91),
                // ruleId = 111
                new SubRule(100, 1, new Variable(true, "name", "STRING"), new Variable(true, "zhang", "STRING"), "CONTAINS", 111),
                new SubRule(101, 2, new Variable(true, "sex", "INTEGER"), new Variable(false, "1", "INTEGER"), "EQUAL", 111),
                new SubRule(102, 3, new Variable(true, "avg_score", "DOUBLE"), new Variable(false, "90.0", "DOUBLE"), "GREATER_EQUAL", 111),
                // ruleId = 311  !(age <= 20)
                new SubRule(102, 1, new Variable(true, "age", "INTEGER"), new Variable(false, "20", "INTEGER"), "LESS_EQUAL", 311)
        );

        List<Rule> rules = List.of(
                new Rule(91, "规则1&2", "1&2"),
                new Rule(111, "规则1|(2&3)", "1|(2&3)"),
                new Rule(211, "规则!1&2", "!1&2"),
                new Rule(311, "规则!1", "!1")
        );

        for (SubRule subRule : subRules) {
            subRuleExpressionMap.computeIfAbsent(subRule.getRuleId(), k -> new HashMap<>()).put(subRule.getNumber(), parseSubRule(subRule));
        }

        for (Rule rule : rules) {
            try {
                String ruleExpression = parseRule(rule, subRuleExpressionMap);
                Expression compiledExpression = AviatorEvaluator.compile(ruleExpression);
                compiledRuleExpressionMap.put(rule.getId(), new CompiledRuleExpression(ruleExpression, compiledExpression));
            } catch (Exception e) {
                System.out.println("rule script compile error. e: " + e.getMessage());
            }
        }
    }

    private String parseSubRule(SubRule subRule) {
        String leftExpr = subRule.getLeftVar().getValue();
        String rightExpr = subRule.getRightVar().getValue();
        String dataType = subRule.getLeftVar().getDataType();
        String operator = subRule.getOperator();
        if ("CONTAINS".equalsIgnoreCase(operator)) {
            return "string.contains(" + leftExpr + ", '" + rightExpr + "')";
        } else if ("NOT_CONTAINS".equalsIgnoreCase(operator)) {
            return "!string.contains(" + leftExpr + ", " + rightExpr + ")";
        } else {
            // TODO: 切换枚举
            if ("ENUM".equalsIgnoreCase(dataType) || "STRING".equalsIgnoreCase(dataType)) {
                return leftExpr + " " + opMap.get(subRule.getOperator()) + " '" + rightExpr + "'";
            }
            return leftExpr + " " + opMap.get(subRule.getOperator()) + " " + rightExpr;
        }
    }

    private String parseRule(Rule rule, Map<Integer, Map<Integer, String>> subRuleExpressions) {
        String expression = rule.getCalcLogic();

        // 替换运算符
        expression = RuleEngine.replaceOperator(expression);

        Map<Integer, String> subRuleExpressionMap = subRuleExpressions.get(rule.getId());
        if (subRuleExpressionMap != null && !subRuleExpressionMap.isEmpty()) {
            for (Map.Entry<Integer, String> subExpr : subRuleExpressionMap.entrySet()) {
                expression = expression.replace(String.valueOf(subExpr.getKey()), "(" + subExpr.getValue() + ")");
            }
        }
        return expression;
    }

    public Map<Integer, CompiledRuleExpression> getCompiledRuleExpressionMap() {
        return compiledRuleExpressionMap;
    }
}
