package com.ali.wb.survey.aviator_script_survey.demo.mock;

import com.ali.wb.survey.aviator_script_survey.demo.entity.Rule;

import java.util.ArrayList;
import java.util.List;

public class RuleDataMock {
    public static List<Rule> getRuleList() {
        List<Rule> ruleList = new ArrayList<>();
        ruleList.add(new Rule(91, "规则id91的规则", "1&2"));
        ruleList.add(new Rule(111, "规则111", "1|(2&3)"));
        ruleList.add(new Rule(200, "规则200", "!1&2"));
        return ruleList;
    }
}
