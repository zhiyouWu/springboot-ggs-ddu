package com.ali.wb.survey.aviator_script_survey.demo.entity;

public class Rule {
    int id;
    String name;
    String calcLogic;

    public Rule(int id, String name, String calcLogic) {
        this.id = id;
        this.name = name;
        this.calcLogic = calcLogic;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCalcLogic() {
        return calcLogic;
    }

    public void setCalcLogic(String calcLogic) {
        this.calcLogic = calcLogic;
    }
}
