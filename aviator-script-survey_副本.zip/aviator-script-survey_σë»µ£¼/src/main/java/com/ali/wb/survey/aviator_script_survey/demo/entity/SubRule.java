package com.ali.wb.survey.aviator_script_survey.demo.entity;

public class SubRule {
    int id;
    int number;
    Variable leftVar;
    Variable rightVar;
    String operator;
    int ruleId;

    public SubRule(int id, int number, Variable leftVar, Variable rightVar, String operator, int ruleId) {
        this.id = id;
        this.number = number;
        this.leftVar = leftVar;
        this.rightVar = rightVar;
        this.operator = operator;
        this.ruleId = ruleId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public Variable getLeftVar() {
        return leftVar;
    }

    public void setLeftVar(Variable leftVar) {
        this.leftVar = leftVar;
    }

    public Variable getRightVar() {
        return rightVar;
    }

    public void setRightVar(Variable rightVar) {
        this.rightVar = rightVar;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public int getRuleId() {
        return ruleId;
    }

    public void setRuleId(int ruleId) {
        this.ruleId = ruleId;
    }
}
