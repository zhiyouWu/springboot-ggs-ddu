package com.ali.wb.survey.aviator_script_survey.demo.entity;

public class Variable {
    boolean isVar;
    String value;
    String dataType;

    public Variable(boolean isVar, String value, String dataType) {
        this.isVar = isVar;
        this.value = value;
        this.dataType = dataType;
    }

    public boolean isVar() {
        return isVar;
    }

    public void setVar(boolean var) {
        isVar = var;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
}
