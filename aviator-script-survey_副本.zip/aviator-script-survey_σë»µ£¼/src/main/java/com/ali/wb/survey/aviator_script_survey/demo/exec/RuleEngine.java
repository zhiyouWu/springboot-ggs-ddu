package com.ali.wb.survey.aviator_script_survey.demo.exec;

import com.ali.wb.survey.aviator_script_survey.demo.entity.Rule;
import com.ali.wb.survey.aviator_script_survey.demo.entity.SubRule;
import com.ali.wb.survey.aviator_script_survey.demo.mock.RuleDataMock;
import com.ali.wb.survey.aviator_script_survey.demo.mock.SubRuleDataMock;
import com.googlecode.aviator.AviatorEvaluator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RuleEngine {

    public static void main(String[] args) {

        // 获取rule集合
        List<Rule> ruleList = RuleDataMock.getRuleList();
        Map<Integer, Map<Integer, String>> subRuleExpressions = new HashMap<>();
        List<SubRule> subRuleList = SubRuleDataMock.getAllSubRuleList();
        for (SubRule subRule : subRuleList) {
            subRuleExpressions.computeIfAbsent(subRule.getRuleId(), k -> new HashMap<>()).put(subRule.getNumber(), parseSubRule(subRule));
        }
        Map<Integer, String> ruleExpressions = new HashMap<>();
        for (Rule rule : ruleList) {
            ruleExpressions.put(rule.getId(), parseRule(rule, subRuleExpressions));
        }

        Map<String, Object> context = new HashMap<>();
        context.put("yw_score", 100);

        for (Map.Entry<Integer, String> entry : ruleExpressions.entrySet()) {
            System.out.println("entry: " + entry);
            try {
                Object result = AviatorEvaluator.execute(entry.getValue(), context);
                System.out.println("   ");
                System.out.println("Rule ID " + entry.getKey() + " executed result: " + result);
                System.out.println("   ");
            } catch (Exception e) {
                System.out.println("Rule ID " + entry.getKey() + " executed result: false, error: " + e.getMessage());
            }
        }
    }

    private static String parseSubRule(SubRule subRule) {
        String leftExpr = subRule.getLeftVar().getValue();
        String rightExpr = subRule.getRightVar().getValue();

        Map<String, String> opMap = new HashMap<>();
        opMap.put("EQUAL", "==");
        opMap.put("LESS", "<");
        opMap.put("GREATER", ">");
        opMap.put("LESS_EQUAL", "<=");
        opMap.put("GREATER_EQUAL", ">=");
        opMap.put("NOT_EQUAL", "!=");

        return leftExpr + " " + opMap.get(subRule.getOperator()) + " " + rightExpr;
    }

    private static String parseRule(Rule rule, Map<Integer, Map<Integer, String>> subRuleExpressions) {
        String expression = rule.getCalcLogic();

        // 替换运算符
        expression = replaceOperator(expression);

        Map<Integer, String> subRuleExpressionMap = subRuleExpressions.get(rule.getId());
        if (subRuleExpressionMap != null && !subRuleExpressions.isEmpty()) {
            for (Map.Entry<Integer, String> subExpr : subRuleExpressionMap.entrySet()) {
                expression = expression.replace(String.valueOf(subExpr.getKey()), "(" + subExpr.getValue() + ")");
            }
        }
        return expression;
    }

    public static String replaceOperator(String expression) {
        expression = expression.replaceAll("&", " && ");
        expression = expression.replaceAll("\\|", " || ");
        return expression;
    }
}
