package com.ali.wb.survey.aviator_script_survey.demo.mock;

import com.ali.wb.survey.aviator_script_survey.demo.entity.SubRule;
import com.ali.wb.survey.aviator_script_survey.demo.entity.Variable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SubRuleDataMock {
    static Map<Integer, List<SubRule>> map = new HashMap<>();
    static {
        List<SubRule> subRule91List = new ArrayList<>();
        subRule91List.add(new SubRule(1, 1, new Variable(true, "yw_score", "INTEGER"), new Variable(false, "80", ""), "LESS", 91));
        subRule91List.add(new SubRule(2, 2, new Variable(true, "en_score", "INTEGER"), new Variable(false, "70", ""), "GRANTER", 91));
        map.put(91, subRule91List);

        map.put(111, new ArrayList<>());
        map.put(211, new ArrayList<>());
    }


    public static List<SubRule> getSubRuleListByRuleId(int ruleId) {
        return map.get(ruleId);
    }

    public static List<SubRule> getAllSubRuleList() {
        List<SubRule> subRuleList = new ArrayList<>();
        subRuleList.add(new SubRule(1, 1, new Variable(true, "yw_score", "INTEGER"), new Variable(false, "90", ""), "GREATER", 91));
        subRuleList.add(new SubRule(2, 2, new Variable(true, "yw_score", "INTEGER"), new Variable(false, "130", ""), "LESS", 91));
        return subRuleList;
    }
}
