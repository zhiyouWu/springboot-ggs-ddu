package com.ali.wb.survey.aviator_script_survey.demo.exec;

import com.ali.wb.survey.aviator_script_survey.demo.entity.CompiledRuleExpression;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class RuleEngineService {
    @Autowired
    private RuleConfigService ruleConfigService;

    public void evaluateRules(Map<String, Object> context) {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressions = ruleConfigService.getCompiledRuleExpressionMap();
        for (Map.Entry<Integer, CompiledRuleExpression> entry : compiledRuleExpressions.entrySet()) {
            try {
                CompiledRuleExpression compiledRuleExpression = entry.getValue();
                Object result = compiledRuleExpression.getCompiledExpression().execute(context);
                System.out.println("   ");
                System.out.println("   ");
                System.out.println("Rule ID " + entry.getKey() + " executed result: " + result);
                System.out.println("   ");
                System.out.println("   ");
            } catch (Exception e) {
                System.out.println("Error evaluating rule ID " + entry.getKey() + ": " + e.getMessage());
                System.out.println("   ");
            }
        }
    }
}
