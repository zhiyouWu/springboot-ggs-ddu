package com.ali.wb.survey.aviator_script_survey.demo.exec;

import com.ali.wb.survey.aviator_script_survey.demo.entity.CompiledRuleExpression;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Expression;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class RuleEngineServiceTest {

    @Autowired
    private RuleEngineService ruleEngineService;

    @Autowired
    private RuleConfigService ruleConfigService;

    /**
     * 测试script是否符合预期
     */
    @Test
    public void testRuleLoading() {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = ruleConfigService.getCompiledRuleExpressionMap();
        assertNotNull(compiledRuleExpressionMap);
        assertFalse(compiledRuleExpressionMap.isEmpty());
        assertTrue(compiledRuleExpressionMap.containsKey(91));
        assertTrue(compiledRuleExpressionMap.containsKey(111));

        // 验证具体的规则表达式
        CompiledRuleExpression compiledRule91Expression = compiledRuleExpressionMap.get(91);
        assertEquals("(yw_score >= 90) && (yw_score <= 130)", compiledRule91Expression.getOriginalExpressionStr());

        CompiledRuleExpression compiledRule111Expression = compiledRuleExpressionMap.get(111);
        assertEquals("(string.contains(name, zhang)) || ((sex == 1) && (avg_score >= 90.0))", compiledRule111Expression.getOriginalExpressionStr());
    }


    /**
     * 测试规则91的数据
     */
    @Test
    public void testRule91() {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = ruleConfigService.getCompiledRuleExpressionMap();
        CompiledRuleExpression compiledRuleExpression = compiledRuleExpressionMap.get(91);
        assertNotNull(compiledRuleExpression);
        String originalExpressionStr = compiledRuleExpression.getOriginalExpressionStr();
        System.out.println("method testMateRule() variable originalExpressionStr: " + originalExpressionStr);
        Expression compiledExpression = compiledRuleExpression.getCompiledExpression();
        assertNotNull(compiledExpression);
        Map<String, Object> context = new HashMap<>();
        // 条件： (yw_score >= 90) && (yw_score <= 130)
        context.put("yw_score", 100);
        // context.put("yw_score", 80);
        // context.put("yw_score", 150);
        Object execute = compiledExpression.execute(context);
        assertTrue((Boolean) execute);
    }


    /**
     * 测试规则111的数据
     */
    @Test
    public void testRule111() {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = ruleConfigService.getCompiledRuleExpressionMap();
        CompiledRuleExpression compiledRuleExpression = compiledRuleExpressionMap.get(111);
        assertNotNull(compiledRuleExpression);
        String originalExpressionStr = compiledRuleExpression.getOriginalExpressionStr();
        System.out.println("method testMateRule() variable originalExpressionStr: " + originalExpressionStr);
        Expression compiledExpression = compiledRuleExpression.getCompiledExpression();
        assertNotNull(compiledExpression);
        Map<String, Object> context = new HashMap<>();
        // 条件：(string.contains(name, 'zhang')) || ((sex == 1) && (avg_score >= 90.0))
        context.put("name", "zhangsan");
        // context.put("name", "");
        context.put("sex", 1);
        // context.put("sex", 0);
        context.put("avg_score", 99.5);
        // context.put("avg_score", 80.0);
        Object execute = compiledExpression.execute(context);
        assertTrue((Boolean) execute);
    }

    /**
     * 测试非运算
     */
    @Test
    public void testNotOperationRule311() {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = ruleConfigService.getCompiledRuleExpressionMap();
        CompiledRuleExpression compiledRuleExpression = compiledRuleExpressionMap.get(311);
        assertNotNull(compiledRuleExpression);
        String originalExpressionStr = compiledRuleExpression.getOriginalExpressionStr();
        System.out.println("method testNotOperationRule() variable originalExpressionStr: " + originalExpressionStr);
        Expression compiledExpression = compiledRuleExpression.getCompiledExpression();
        assertNotNull(compiledExpression);
        Map<String, Object> context = new HashMap<>();
        // 条件
        context.put("age", 21);
        // context.put("age", 18);
        Object execute = compiledExpression.execute(context);
        assertTrue((Boolean) execute);
    }

    /**
     * 测试不存在的规则id
     */
    @Test
    public void testNotExistedRule() {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = ruleConfigService.getCompiledRuleExpressionMap();
        CompiledRuleExpression compiledRuleExpression = compiledRuleExpressionMap.get(200);
        assertNotNull(compiledRuleExpression);
        String originalExpressionStr = compiledRuleExpression.getOriginalExpressionStr();
        System.out.println("method testNotExistedRule() variable originalExpressionStr: " + originalExpressionStr);
        Expression compiledExpression = compiledRuleExpression.getCompiledExpression();
        assertNotNull(compiledExpression);
        Map<String, Object> context = new HashMap<>();
        Object execute = compiledExpression.execute(context);
        assertTrue((Boolean) execute);
    }

    /**
     * 测试子规则不存在的规则-211
     */
    @Test
    public void testSubRuleNotExisted() {
        Map<Integer, CompiledRuleExpression> compiledRuleExpressionMap = ruleConfigService.getCompiledRuleExpressionMap();
        CompiledRuleExpression compiledRuleExpression = compiledRuleExpressionMap.get(211);
        assertNotNull(compiledRuleExpression);
        String originalExpressionStr = compiledRuleExpression.getOriginalExpressionStr();
        System.out.println("method testSubRuleNotExisted() variable originalExpressionStr: " + originalExpressionStr);
        Expression compiledExpression = compiledRuleExpression.getCompiledExpression();
        assertNotNull(compiledExpression);
        Map<String, Object> context = new HashMap<>();
        Object execute = compiledExpression.execute(context);
        assertTrue((Boolean) execute);
    }




}
