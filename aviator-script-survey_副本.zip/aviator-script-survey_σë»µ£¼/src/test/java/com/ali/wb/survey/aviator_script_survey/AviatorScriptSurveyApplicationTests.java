package com.ali.wb.survey.aviator_script_survey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AviatorScriptSurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
